<?php
/**
 * Plugin Name:			Steve Interactive Map
 * Plugin URI:
 * Description:			Map stuff
 * Version:				1.0.0
 * Author:				SteveMoretz
 * Author URI:			https://www.freelancer.com/u/SteveMoretzPro
 *
 * Text Domain: steve-moretz-interactive-map
 * Domain Path: /languages
 *
 * @package InteractiveMap
 * @category Core
 * @author SteveMoretz
 */

require_once __DIR__ . '/map/index.php';

