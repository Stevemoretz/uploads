<?php

add_shortcode('steve-moretz-africa-map-current-areas',static function(){
	ob_start();
	require_once __DIR__ .'/map.php';
	return ob_get_clean();
});
add_shortcode('steve-moretz-our-geographical-footprint',static function(){
	ob_start();
	require_once __DIR__ .'/map2.php';
	return ob_get_clean();
});

add_action('wp_enqueue_scripts',static function(){
	wp_enqueue_script('steve_moretz_map',plugin_dir_url(__DIR__ . '/assets/map.js') . 'map.js',['jquery'],WP_DEBUG ? microtime() : '1.0',false);
	wp_enqueue_script('steve_moretz_map_jquery_maphilight',plugin_dir_url(__DIR__ . '/assets/jquery.imagemapster.min.js') . 'jquery.imagemapster.min.js',[],WP_DEBUG ? microtime() : '1.0',false);
	wp_enqueue_style('steve_moretz_map_stylesheet',plugin_dir_url(__DIR__ . '/assets/map.css') . 'map.css',[],WP_DEBUG ? microtime() : '1.0','all');
});
